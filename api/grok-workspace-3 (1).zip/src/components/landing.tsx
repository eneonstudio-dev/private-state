import { useEffect, useRef, useState } from "react";
import { clsx } from "clsx";
import { Instagram } from "lucide-react";
import {
  INSTAGRAM,
  INSTAGRAM_URL,
  PACKAGES,
  TELEGRAM_URL,
  translations,
  type Lang,
} from "@/lib/copy";
import { media } from "@/lib/media";

const PKG_KEYS: Record<string, { desc: string; items: string[] }> = {
  offline: {
    desc: "offlineDesc",
    items: ["offline1", "offline2", "offline3", "offline4"],
  },
  darkness: {
    desc: "darknessDesc",
    items: ["darkness1", "darkness2", "darkness3", "darkness4"],
  },
  private: {
    desc: "privateDesc",
    items: ["private1", "private2", "private3", "private4"],
  },
  sovereign: {
    desc: "sovereignDesc",
    items: ["sovereign1", "sovereign2", "sovereign3", "sovereign4"],
  },
};

const GALLERY = [
  { src: media("/images/hero.jpg"), cap: "01 · FOREST" },
  { src: media("/images/house.jpg"), cap: "02 · VILLA" },
  { src: media("/images/house-2.jpg"), cap: "03 · NIGHT" },
  { src: media("/images/house-3.jpg"), cap: "04 · GLASS" },
  { src: media("/images/house-private.jpg"), cap: "05 · PRIVATE" },
  { src: media("/images/house-4.jpg"), cap: "06 · WATER" },
  { src: media("/images/pool.jpg"), cap: "07 · POOL" },
  { src: media("/images/spa.jpg"), cap: "08 · SPA" },
];

const BOOT_MS = 3400;

export function Landing() {
  const [lang, setLang] = useState<Lang>("ru");
  const [boot, setBoot] = useState(true);
  const [typed, setTyped] = useState("");
  const [offline, setOffline] = useState(false);
  const t = translations[lang];

  useEffect(() => {
    try {
      if (sessionStorage.getItem("ps-boot-v4") === "1") {
        setBoot(false);
        return;
      }
    } catch {
      /* ignore */
    }
    const id = window.setTimeout(() => {
      try {
        sessionStorage.setItem("ps-boot-v4", "1");
      } catch {
        /* ignore */
      }
      setBoot(false);
    }, BOOT_MS);
    return () => window.clearTimeout(id);
  }, []);

  useEffect(() => {
    if (boot) return;
    const full = t.typewriter;
    setTyped("");
    let i = 0;
    const id = window.setInterval(() => {
      i += 1;
      setTyped(full.slice(0, i));
      if (i >= full.length) window.clearInterval(id);
    }, 28);
    return () => window.clearInterval(id);
  }, [boot, t.typewriter]);

  const generalTg = TELEGRAM_URL;

  return (
    <div className="min-h-svh bg-bg text-fg">
      {boot && <BootScreen t={t} />}

      <header className="fixed inset-x-0 top-0 z-40 flex items-center justify-between bg-bg/80 px-5 py-4 backdrop-blur-md md:px-16">
        <a href="#top" className="flex items-center gap-3 no-underline">
          <span className="font-mono text-xs tracking-[0.28em]">
            P<span className="mx-1 inline-block size-1.5 rounded-full bg-green" />S
          </span>
          <span className="hidden font-mono text-xs tracking-widest text-dim sm:inline">
            PRIVATE STATE
          </span>
        </a>
        <div className="flex items-center gap-3">
          {(["ru", "en", "zh"] as const).map((code) => (
            <button
              key={code}
              type="button"
              onClick={() => setLang(code)}
              className={clsx(
                "font-mono text-xs tracking-widest",
                lang === code ? "text-green" : "text-dim hover:text-fg",
              )}
            >
              {code.toUpperCase()}
            </button>
          ))}
          <a
            href={TELEGRAM_URL}
            target="_blank"
            rel="noreferrer"
            className="flex size-9 items-center justify-center rounded-full border border-border text-green no-underline hover:border-green"
            aria-label="Telegram"
          >
            <TgIcon />
          </a>
          <a
            href={INSTAGRAM_URL}
            target="_blank"
            rel="noreferrer"
            className="flex size-9 items-center justify-center rounded-full border border-border text-green no-underline hover:border-green"
            aria-label="Instagram"
          >
            <Instagram className="size-3.5" strokeWidth={1.7} />
          </a>
        </div>
      </header>

      <main id="top">
        <section className="relative flex min-h-svh items-center overflow-hidden px-5 pb-24 pt-28 md:px-16">
          <HeroMedia
            sources={[media("/video/estate.mp4"), media("/video/spa.mp4")]}
            poster={media("/images/hero.jpg")}
          />
          <div className="absolute inset-0 bg-gradient-to-b from-bg/40 via-bg/55 to-bg" />
          <div className="relative z-10 w-full max-w-6xl">
            <p className="mb-6 flex items-center gap-3 font-mono text-xs tracking-widest text-muted">
              <span className="size-1.5 rounded-full bg-green" />
              {t.kicker}
            </p>
            <h1 className="text-6xl font-medium leading-none tracking-tighter md:text-8xl lg:text-9xl">
              {t.hero1}
              <span className="mt-1 block text-green">{t.hero2}</span>
            </h1>
            <p className="mt-8 max-w-xl font-mono text-sm leading-relaxed text-muted md:text-base">
              {typed}
              <span className="ml-1 inline-block h-4 w-1.5 translate-y-0.5 bg-green" />
            </p>
          </div>
          <div className="absolute inset-x-5 bottom-8 z-10 flex items-end justify-between md:inset-x-16">
            <p className="hidden font-mono text-xs text-dim sm:block">
              MOSCOW REGION
            </p>
            <p className="font-mono text-xs tracking-widest text-dim">{t.scroll}</p>
          </div>
        </section>

        <section className="px-5 py-24 md:px-16">
          <div className="mx-auto grid max-w-6xl gap-10 md:grid-cols-2">
            <div>
              <p className="mb-4 font-mono text-xs tracking-widest text-green">
                // {t.concept}
              </p>
              <h2 className="text-4xl font-medium tracking-tight md:text-6xl">
                {t.quote1}
                <span className="mt-2 block text-muted">{t.quote2}</span>
              </h2>
            </div>
            <div className="flex flex-col justify-end">
              <p className="text-sm leading-relaxed text-muted md:text-base">
                {t.intro1}
              </p>
              <p className="mt-4 text-sm leading-relaxed text-muted md:text-base">
                {t.intro2}
              </p>
            </div>
          </div>
        </section>

        <section className="px-5 pb-24 md:px-16">
          <div className="mx-auto max-w-6xl">
            <p className="mb-6 font-mono text-xs tracking-widest text-green">
              // {t.swipe}
            </p>
            <SwipeGallery items={GALLERY} />
          </div>
        </section>

        <section className="px-5 py-10 md:px-16" id="formats">
          <div className="mx-auto max-w-6xl">
            <p className="mb-3 font-mono text-xs tracking-widest text-green">
              // {t.choose}
            </p>
            <h2 className="text-4xl font-medium tracking-tight md:text-6xl">
              {t.three}
            </h2>
            <p className="mt-4 font-mono text-xs text-dim">{t.note}</p>
            <div className="mt-12 grid gap-3 md:grid-cols-2">
              {PACKAGES.map((pkg) => {
                const keys = PKG_KEYS[pkg.id];
                const epic = Boolean(pkg.epic);
                return (
                  <article
                    key={pkg.id}
                    className={clsx(
                      "relative overflow-hidden border border-border",
                      epic && "md:col-span-2",
                    )}
                  >
                    <img
                      src={pkg.bg}
                      alt=""
                      className="absolute inset-0 size-full object-cover opacity-40"
                      loading="lazy"
                      decoding="async"
                    />
                    <div className="relative bg-bg/70 p-6 md:p-8">
                      <div className="flex items-center justify-between gap-3">
                        <p className="font-mono text-xs tracking-widest text-green">
                          {pkg.code}
                        </p>
                        {pkg.featured && (
                          <span className="font-mono text-xs text-green">
                            {t.featured}
                          </span>
                        )}
                        {epic && (
                          <span className="font-mono text-xs text-green">
                            {t.epic}
                          </span>
                        )}
                      </div>
                      <h3 className="mt-4 text-3xl font-medium tracking-tight md:text-5xl">
                        {pkg.name}
                      </h3>
                      <p className="mt-2 font-mono text-sm text-green">
                        {t.from} {pkg.price}
                      </p>
                      <p className="mt-5 max-w-2xl text-sm leading-relaxed text-muted">
                        {t[keys.desc]}
                      </p>
                      <ul className="mt-6 max-w-xl">
                        {keys.items.map((key) => (
                          <li
                            key={key}
                            className="border-b border-border py-2.5 text-sm text-muted"
                          >
                            <span className="mr-2 text-green">↗</span>
                            {t[key]}
                          </li>
                        ))}
                      </ul>
                      <a
                        href={TELEGRAM_URL}
                        target="_blank"
                        rel="noreferrer"
                        className="mt-7 inline-block font-mono text-xs tracking-widest text-fg no-underline hover:text-green"
                      >
                        {epic ? t.request : t.select}
                      </a>
                    </div>
                  </article>
                );
              })}
            </div>
          </div>
        </section>

        <section className="relative min-h-svh overflow-hidden">
          <LazyVideo
            src={media("/video/spa.mp4")}
            poster={media("/images/pool.jpg")}
            className="absolute inset-0"
            fit
          />
          <div className="absolute inset-0 bg-gradient-to-t from-bg via-bg/50 to-bg/30" />
          <div className="relative z-10 flex min-h-svh items-end px-5 py-20 md:px-16">
            <div className="max-w-3xl">
              <p className="mb-4 font-mono text-xs tracking-widest text-green">
                // {t.cinema}
              </p>
              <h2 className="text-4xl font-medium tracking-tight md:text-6xl">
                {t.cinemaTitle}
              </h2>
              <p className="mt-5 max-w-xl text-sm leading-relaxed text-muted md:text-base">
                {t.cinemaLead}
              </p>
            </div>
          </div>
        </section>

        <section className="px-5 py-24 md:px-16" id="protocol">
          <div className="mx-auto max-w-6xl">
            <p className="mb-3 font-mono text-xs tracking-widest text-green">
              // {t.protocol}
            </p>
            <h2 className="text-4xl font-medium tracking-tight md:text-6xl">
              {t.protocolTitle}
            </h2>
            <p className="mt-4 max-w-xl text-sm text-muted">{t.protocolLead}</p>
            <ProtocolFilm t={t} />
          </div>
        </section>

        <section className="px-5 py-24 md:px-16">
          <div className="mx-auto grid max-w-6xl items-center gap-12 md:grid-cols-2">
            <PhoneStage offline={offline} onToggle={() => setOffline((v) => !v)} />
            <div>
              <p className="mb-4 font-mono text-xs tracking-widest text-green">
                // {t.phone}
              </p>
              <h2 className="text-4xl font-medium tracking-tight md:text-5xl">
                {t.phoneTitle}
              </h2>
              <p className="mt-5 text-sm leading-relaxed text-muted">{t.phoneLead}</p>
              <div className="mt-8 border-t border-border">
                {[
                  ["01", t.t1, t.t1t],
                  ["02", t.t2, t.t2t],
                  ["03", t.t3, t.t3t],
                ].map(([n, title, body]) => (
                  <div
                    key={n}
                    className="grid grid-cols-[3rem_1fr] border-b border-border py-5"
                  >
                    <span className="font-mono text-xs text-green">{n}</span>
                    <div>
                      <p className="text-sm">{title}</p>
                      <p className="mt-1 text-xs leading-relaxed text-dim">{body}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        <section className="px-5 py-24 md:px-16" id="concierge">
          <div className="mx-auto max-w-6xl">
            <p className="mb-3 font-mono text-xs tracking-widest text-green">
              // {t.concierge}
            </p>
            <h2 className="max-w-3xl text-4xl font-medium tracking-tight md:text-5xl">
              {t.conciergeTitle}
            </h2>
            <p className="mt-5 max-w-xl text-sm leading-relaxed text-muted">
              {t.conciergeText}
            </p>
            <ConciergePortrait t={t} />
            <div className="mt-4 grid gap-4 md:grid-cols-2">
              <div className="overflow-hidden border border-border">
                <img
                  src={media("/images/security.jpg")}
                  alt=""
                  className="h-48 w-full object-cover"
                  loading="lazy"
                  decoding="async"
                />
                <p className="px-3 py-2 font-mono text-xs tracking-widest text-green">
                  {t.guard}
                </p>
              </div>
              <div className="border border-border bg-bg-soft p-5">
                <p className="mb-3 font-mono text-xs tracking-widest text-green">
                  {t.important}
                </p>
                <p className="text-sm leading-relaxed text-muted">{t.importantText}</p>
              </div>
            </div>
          </div>
        </section>

        <section className="px-5 py-20 md:px-16">
          <div className="mx-auto max-w-6xl">
            <p className="mb-3 font-mono text-xs tracking-widest text-green">
              // {t.built}
            </p>
            <h2 className="text-4xl font-medium tracking-tight md:text-6xl">
              {t.servicesTitle}
            </h2>
            <p className="mt-4 max-w-xl text-sm leading-relaxed text-muted">
              {t.servicesLead}
            </p>
            <div className="mt-12 grid gap-2 sm:grid-cols-2 lg:grid-cols-4">
              {[
                { img: media("/images/house-3.jpg"), title: t.loc, text: t.locT },
                { img: media("/images/spa.jpg"), title: t.spa, text: t.spaT },
                { img: media("/images/pool.jpg"), title: t.pool, text: t.poolT },
                { img: media("/images/room.jpg"), title: t.priv, text: t.privT },
              ].map((card) => (
                <article key={card.title} className="border border-border bg-surface">
                  <img
                    src={card.img}
                    alt=""
                    className="h-40 w-full object-cover"
                    loading="lazy"
                    decoding="async"
                  />
                  <div className="p-5">
                    <p className="mb-2 font-mono text-xs tracking-widest text-green">
                      {card.title}
                    </p>
                    <p className="text-xs leading-relaxed text-muted">{card.text}</p>
                  </div>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section className="relative min-h-svh overflow-hidden">
          <LazyVideo
            src={media("/video/moscow.mp4")}
            poster={media("/images/house-5.jpg")}
            className="absolute inset-0"
            fit
          />
          <div className="absolute inset-0 bg-gradient-to-t from-bg via-bg/70 to-bg/40" />
          <div className="relative z-10 mx-auto flex min-h-svh max-w-6xl flex-col justify-end px-5 py-20 md:px-16">
            <p className="mb-4 font-mono text-xs tracking-widest text-green">
              // {t.arrival}
            </p>
            <h2 className="max-w-3xl text-4xl font-medium tracking-tight md:text-6xl">
              {t.arrivalTitle}
            </h2>
            <p className="mt-5 max-w-xl text-sm leading-relaxed text-muted md:text-base">
              {t.arrivalText}
            </p>
            <p className="mt-8 font-mono text-xs tracking-widest text-green">
              MOSCOW REGION
              <span className="mt-2 block text-dim">{t.arrivalPin}</span>
            </p>
          </div>
        </section>

        <section className="px-5 py-20 md:px-16">
          <div className="mx-auto max-w-6xl">
            <p className="mb-8 font-mono text-xs tracking-widest text-green">
              // {t.trust}
            </p>
            <div className="grid gap-3 md:grid-cols-3">
              {[
                [t.trust1, t.trust1t],
                [t.trust2, t.trust2t],
                [t.trust3, t.trust3t],
              ].map(([title, body]) => (
                <article
                  key={title}
                  className="border border-border bg-surface p-6"
                >
                  <p className="font-mono text-xs tracking-widest text-green">
                    {title}
                  </p>
                  <p className="mt-3 text-sm leading-relaxed text-muted">{body}</p>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section className="px-5 py-20 md:px-16" id="faq">
          <div className="mx-auto max-w-6xl">
            <p className="mb-3 font-mono text-xs tracking-widest text-green">
              // {t.faq}
            </p>
            <h2 className="text-4xl font-medium tracking-tight md:text-6xl">
              {t.faqTitle}
            </h2>
            <p className="mt-4 max-w-xl text-sm text-muted">{t.faqLead}</p>
            <div className="mt-10 border-t border-border">
              {(["1", "2", "3", "4", "5", "6"] as const).map((n) => (
                <details key={n} className="group border-b border-border">
                  <summary className="flex min-h-14 cursor-pointer list-none items-center justify-between gap-4 py-4 text-left text-sm">
                    <span>{t[`q${n}`]}</span>
                    <span className="font-mono text-green group-open:rotate-45">
                      +
                    </span>
                  </summary>
                  <p className="pb-5 text-sm leading-relaxed text-muted">
                    {t[`a${n}`]}
                  </p>
                </details>
              ))}
            </div>
          </div>
        </section>

        <section
          id="request"
          className="relative flex min-h-svh flex-col items-center justify-center overflow-hidden px-5 py-24 text-center"
        >
          <img
            src={media("/images/estate.jpg")}
            alt=""
            className="absolute inset-0 size-full object-cover"
            loading="lazy"
            decoding="async"
          />
          <div className="absolute inset-0 bg-bg/80" />
          <div className="relative z-10 flex flex-col items-center">
            <p className="mb-6 font-mono text-xs tracking-widest text-green">
              // {t.final}
            </p>
            <h2 className="text-6xl font-medium leading-none tracking-tighter md:text-8xl lg:text-9xl">
              {t.ready}
              <span className="mt-2 block text-green">{t.disappear}</span>
            </h2>
            <p className="mt-8 max-w-lg text-sm leading-relaxed text-muted">
              {t.finalText}
            </p>
            <div className="mt-10 flex w-full max-w-sm flex-col gap-3">
              <a
                href={generalTg}
                target="_blank"
                rel="noreferrer"
                className="inline-flex min-h-12 items-center justify-center gap-3 bg-green px-6 font-mono text-xs tracking-widest text-bg no-underline hover:bg-transparent hover:text-green hover:ring-1 hover:ring-green"
              >
                <TgIcon />
                {t.tg}
              </a>
              <a
                href={INSTAGRAM_URL}
                target="_blank"
                rel="noreferrer"
                className="inline-flex min-h-12 items-center justify-center gap-3 border border-green px-6 font-mono text-xs tracking-widest text-green no-underline hover:bg-green hover:text-bg"
              >
                <Instagram className="size-3.5" strokeWidth={1.7} />
                {t.igWrite}
              </a>
            </div>
            <p className="mt-4 font-mono text-xs text-dim">{t.direct}</p>
            <div className="mt-2 flex items-center gap-4 font-mono text-xs">
              <a
                href={TELEGRAM_URL}
                target="_blank"
                rel="noreferrer"
                className="text-dim no-underline hover:text-green"
              >
                Telegram
              </a>
              <a
                href={INSTAGRAM_URL}
                target="_blank"
                rel="noreferrer"
                className="text-dim no-underline hover:text-green"
              >
                Instagram
              </a>
            </div>
          </div>
        </section>
      </main>

      <footer className="mb-16 flex items-center justify-between px-5 py-8 font-mono text-xs text-dim md:mb-0 md:px-16">
        <span>PRIVATE STATE</span>
        <span>{t.wait}</span>
        <a
          href={INSTAGRAM_URL}
          target="_blank"
          rel="noreferrer"
          className="text-dim no-underline hover:text-green"
        >
          {INSTAGRAM}
        </a>
      </footer>

      <div className="fixed bottom-4 left-4 right-4 z-50 grid grid-cols-2 gap-2 md:hidden">
        <a
          href={generalTg}
          target="_blank"
          rel="noreferrer"
          className="flex min-h-12 items-center justify-center bg-green font-mono text-[10px] tracking-widest text-bg no-underline"
        >
          TELEGRAM
        </a>
        <a
          href={INSTAGRAM_URL}
          target="_blank"
          rel="noreferrer"
          className="flex min-h-12 items-center justify-center border border-green bg-bg font-mono text-[10px] tracking-widest text-green no-underline"
        >
          INSTAGRAM
        </a>
      </div>
    </div>
  );
}

function BootScreen({ t }: { t: Record<string, string> }) {
  return (
    <div className="ps-boot fixed inset-0 z-[100] flex flex-col items-center justify-center bg-bg">
      <div className="pointer-events-none absolute inset-0 overflow-hidden">
        <div className="absolute inset-x-0 h-px bg-green/50 [animation:ps-scan_2.4s_linear_infinite]" />
      </div>
      <div className="ps-boot-inner relative z-10 flex w-full max-w-sm flex-col items-center px-6">
        <p className="font-mono text-xs tracking-[0.4em] text-green">{t.boot}</p>
        <p className="mt-8 text-4xl font-medium tracking-tighter">
          PRIVATE <span className="text-green">STATE</span>
        </p>
        <p className="mt-6 font-mono text-xs tracking-widest text-dim">
          {t.bootWait}
        </p>
        <ol className="mt-10 w-full space-y-3 font-mono text-xs tracking-widest text-muted">
          <li>01 {t.boot1}</li>
          <li>02 {t.boot2}</li>
          <li>03 {t.boot3}</li>
        </ol>
        <div className="mt-10 h-px w-full bg-border">
          <div className="h-px bg-green [animation:ps-bar_2.8s_linear_forwards]" />
        </div>
      </div>
    </div>
  );
}

function HeroMedia({
  sources,
  poster,
}: {
  sources: string[];
  poster: string;
}) {
  const [i, setI] = useState(0);
  const ref = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    const v = ref.current;
    if (!v) return;
    v.muted = true;
    void v.play().catch(() => undefined);
  }, [i]);

  return (
    <video
      ref={ref}
      key={sources[i]}
      className="absolute inset-0 size-full object-cover"
      src={sources[i]}
      poster={poster}
      muted
      playsInline
      autoPlay
      preload={i === 0 ? "auto" : "metadata"}
      loop={sources.length < 2}
      onEnded={() => setI((n) => (n + 1) % sources.length)}
    />
  );
}

function LazyVideo({
  src,
  poster,
  className,
  fit,
}: {
  src: string;
  poster: string;
  className?: string;
  fit?: boolean;
}) {
  const [on, setOn] = useState(false);
  const box = useRef<HTMLDivElement>(null);
  const vid = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    const el = box.current;
    if (!el) return;
    const io = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) setOn(true);
      },
      { rootMargin: "200px", threshold: 0.01 },
    );
    io.observe(el);
    return () => io.disconnect();
  }, []);

  useEffect(() => {
    const v = vid.current;
    if (!v || !on) return;
    void v.play().catch(() => undefined);
  }, [on]);

  return (
    <div ref={box} className={className ?? "relative overflow-hidden"}>
      {on ? (
        <video
          ref={vid}
          className={clsx("size-full object-cover", fit && "absolute inset-0")}
          src={src}
          poster={poster}
          muted
          loop
          playsInline
          preload="metadata"
        />
      ) : (
        <img
          src={poster}
          alt=""
          className={clsx("size-full object-cover", fit && "absolute inset-0")}
        />
      )}
    </div>
  );
}

function SwipeGallery({ items }: { items: { src: string; cap: string }[] }) {
  const [i, setI] = useState(0);
  const start = useRef<number | null>(null);
  const hover = useRef(false);

  const go = (dir: number) =>
    setI((n) => (n + dir + items.length) % items.length);

  useEffect(() => {
    const id = window.setInterval(() => {
      if (!hover.current) go(1);
    }, 4800);
    return () => window.clearInterval(id);
  }, [items.length]);

  const pointerStart = (x: number) => {
    start.current = x;
  };
  const pointerEnd = (x: number) => {
    if (start.current == null) return;
    const dx = x - start.current;
    if (dx > 40) go(-1);
    if (dx < -40) go(1);
    start.current = null;
  };

  return (
    <div
      className="relative select-none overflow-hidden border border-border"
      onMouseEnter={() => {
        hover.current = true;
      }}
      onMouseLeave={() => {
        hover.current = false;
      }}
      onTouchStart={(e) => pointerStart(e.touches[0].clientX)}
      onTouchEnd={(e) => pointerEnd(e.changedTouches[0].clientX)}
      onMouseDown={(e) => pointerStart(e.clientX)}
      onMouseUp={(e) => pointerEnd(e.clientX)}
    >
      <img
        src={items[i].src}
        alt=""
        className="ps-ken aspect-video w-full object-cover"
        decoding="async"
      />
      <div className="absolute inset-x-0 bottom-0 flex items-center justify-between bg-gradient-to-t from-bg to-transparent px-4 py-4">
        <span className="font-mono text-xs tracking-widest">{items[i].cap}</span>
        <div className="flex gap-2">
          {items.map((item, idx) => (
            <button
              key={item.src}
              type="button"
              aria-label={item.cap}
              onClick={() => setI(idx)}
              className={clsx("h-1.5 w-4", idx === i ? "bg-green" : "bg-dim")}
            />
          ))}
        </div>
        <div className="flex gap-2">
          <button
            type="button"
            onClick={() => go(-1)}
            className="min-h-10 min-w-10 border border-border font-mono text-sm hover:border-green"
          >
            ‹
          </button>
          <button
            type="button"
            onClick={() => go(1)}
            className="min-h-10 min-w-10 border border-border font-mono text-sm hover:border-green"
          >
            ›
          </button>
        </div>
      </div>
    </div>
  );
}

function ConciergePortrait({ t }: { t: Record<string, string> }) {
  return (
    <div className="relative mx-auto mt-10 max-w-lg overflow-hidden border border-border md:max-w-2xl">
      <img
        src={media("/images/concierge-f.jpg")}
        alt=""
        className="ps-portrait aspect-[3/4] w-full object-cover object-top"
      />
      <div className="pointer-events-none absolute inset-0">
        <div className="ps-portrait-scan absolute inset-x-0 h-px bg-green/70" />
      </div>
      <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-bg via-bg/70 to-transparent px-5 py-5">
        <p className="flex items-center gap-2 font-mono text-xs tracking-widest text-green">
          <span className="ps-live inline-block size-1.5 rounded-full bg-green" />
          {t.concierge}
        </p>
        <p className="mt-2 text-2xl font-medium tracking-tight">ANNA</p>
      </div>
    </div>
  );
}

function PhoneStage({
  offline,
  onToggle,
}: {
  offline: boolean;
  onToggle: () => void;
}) {
  return (
    <div className="relative overflow-hidden border border-border bg-surface">
      <LazyVideo
        src={media("/video/phone.mp4")}
        poster={media("/images/phone.jpg")}
        className="aspect-video w-full"
      />
      <button
        type="button"
        onClick={onToggle}
        className={clsx(
          "absolute bottom-4 right-4 flex h-40 w-24 flex-col items-center justify-center rounded-3xl border-2 border-dim bg-bg/90",
          offline && "ps-phone-offline border-green",
        )}
      >
        <div className="ps-bars mb-3 flex h-3 items-end gap-0.5">
          {[1, 2, 3, 4].map((n) => (
            <span
              key={n}
              className="w-1 bg-green"
              style={{
                height: `${n * 3}px`,
                animation: "ps-signal 1.6s ease infinite",
                animationDelay: `${n * 120}ms`,
              }}
            />
          ))}
        </div>
        <span className="font-mono text-xs text-green">
          {offline ? "OFFLINE" : "NO SIGNAL"}
        </span>
        <span className="mt-2 font-mono text-xs text-dim">TAP</span>
      </button>
    </div>
  );
}

function ProtocolFilm({ t }: { t: Record<string, string> }) {
  const steps = [
    { poster: media("/images/hero.jpg"), k: "p1" },
    { poster: media("/images/house-5.jpg"), k: "p2" },
    { poster: media("/images/phone.jpg"), k: "p3" },
    { poster: media("/images/spa.jpg"), k: "p4" },
    { poster: media("/images/security.jpg"), k: "p5" },
  ];
  const [i, setI] = useState(0);

  useEffect(() => {
    const id = window.setInterval(() => setI((n) => (n + 1) % steps.length), 4200);
    return () => window.clearInterval(id);
  }, [steps.length]);

  const step = steps[i];

  return (
    <div className="mt-10 grid gap-4 md:grid-cols-[1.4fr_0.6fr]">
      <div className="relative min-h-72 overflow-hidden border border-border">
        <img
          src={step.poster}
          alt=""
          className="size-full min-h-72 object-cover"
        />
        <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-bg p-5">
          <p className="font-mono text-xs tracking-widest text-green">
            0{i + 1} / {t[step.k]}
          </p>
          <p className="mt-2 text-sm text-muted">{t[`${step.k}t`]}</p>
        </div>
      </div>
      <ol className="flex flex-col gap-1">
        {steps.map((s, idx) => (
          <li key={s.k}>
            <button
              type="button"
              onClick={() => setI(idx)}
              className={clsx(
                "flex w-full min-h-12 items-center justify-between border px-4 text-left font-mono text-xs tracking-widest",
                idx === i
                  ? "border-green text-green"
                  : "border-border text-dim hover:text-fg",
              )}
            >
              <span>
                0{idx + 1} {t[s.k]}
              </span>
              <span>→</span>
            </button>
          </li>
        ))}
      </ol>
    </div>
  );
}

function TgIcon() {
  return (
    <svg viewBox="0 0 24 24" className="size-3.5 fill-current" aria-hidden>
      <path d="M21.5 3.4 18.2 20c-.2 1-.8 1.2-1.6.8l-4.4-3.3-2.1 2c-.2.3-.5.5-1 .5l.3-4.5 8.2-7.4c.4-.3 0-.5-.5-.2l-10 6.3-4.3-1.3c-.9-.3-.9-.9.2-1.3L20.2 2.6c.8-.3 1.5.2 1.3.8Z" />
    </svg>
  );
}
