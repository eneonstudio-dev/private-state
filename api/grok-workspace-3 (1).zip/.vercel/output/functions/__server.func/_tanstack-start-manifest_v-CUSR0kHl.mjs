//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CUSR0kHl.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-BEvw_bCF.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BEvw_bCF.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-DN4cFMjE.js"]
	}
} });
//#endregion
export { tsrStartManifest };
