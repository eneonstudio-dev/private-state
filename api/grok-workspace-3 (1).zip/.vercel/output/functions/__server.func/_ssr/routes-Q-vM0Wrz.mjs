import { i as __toESM } from "../_runtime.mjs";
import { L as require_react, v as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as Instagram } from "../_libs/lucide-react.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-Q-vM0Wrz.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function media(path) {
	return `/${path.replace(/^\//, "")}`;
}
var TELEGRAM_URL = "https://t.me/+xFj65mXQpeFhYWNi";
var INSTAGRAM_URL = "https://www.instagram.com/privatstate";
var INSTAGRAM = "privatstate";
var PACKAGES = [
	{
		id: "offline",
		code: "01 / OFFLINE",
		name: "OFFLINE",
		price: "39 000 ₽",
		bg: media("/images/house.jpg")
	},
	{
		id: "darkness",
		code: "02 / DARKNESS",
		name: "DARKNESS",
		price: "69 000 ₽",
		featured: true,
		bg: media("/images/house-2.jpg")
	},
	{
		id: "private",
		code: "03 / PRIVATE",
		name: "PRIVATE",
		price: "ОТ 129 000 ₽",
		bg: media("/images/house-private.jpg")
	},
	{
		id: "sovereign",
		code: "04 / SOVEREIGN",
		name: "SOVEREIGN",
		price: "790 000 ₽",
		epic: true,
		bg: media("/images/estate.jpg")
	}
];
var translations = {
	ru: {
		kicker: "ПРИВАТНЫЙ СЕРВИС · МОСКОВСКАЯ ОБЛАСТЬ",
		hero1: "БУДЬ",
		hero2: "НЕДОСТУПЕН.",
		typewriter: "Вам не нужно исчезать. Вам нужно лишь перестать быть доступным.",
		from: "ОТ",
		scroll: "ЛИСТАЙТЕ, ЧТОБЫ ОТКЛЮЧИТЬСЯ",
		concept: "КОНЦЕПЦИЯ",
		quote1: "Вам не нужно исчезать.",
		quote2: "Достаточно перестать быть доступным.",
		intro1: "PRIVATE STATE — организованное пребывание в цифровой тишине. Приватная резиденция за пределами Москвы: бетон, стекло, лес.",
		intro2: "Вы выбираете формат. Мы готовим локацию, spa, бассейн, прибытие и concierge. Адрес — только после подтверждения.",
		stills: "РЕЗИДЕНЦИЯ",
		still1: "VILLA",
		still2: "SUITE",
		still3: "SPA",
		choose: "ВЫБЕРИТЕ ФОРМАТ",
		three: "Четыре способа стать недоступным.",
		note: "MOSCOW REGION · PRIVATE ESTATES · ₽ RUB",
		offlineDesc: "Базовый формат полного цифрового отключения. Подготовленная вилла, передача телефона concierge, тишина без сети.",
		offline1: "Вилла под ключ",
		offline2: "Телефон у concierge",
		offline3: "Concierge на связи",
		offline4: "Кухня · без трансфера",
		darknessDesc: "Глубже. Индивидуальная подготовка резиденции, spa, бассейн и расширенное сопровождение.",
		darkness1: "Spa и бассейн",
		darkness2: "Трансфер по запросу",
		darkness3: "Расширенное меню",
		darkness4: "Concierge и прибытие",
		privateDesc: "Полностью индивидуальный сценарий. Локация, маршрут, сопровождение и детали — под вас.",
		private1: "Своя вилла и сценарий",
		private2: "Трансфер",
		private3: "Персональный concierge",
		private4: "Кухня и детали под вас",
		sovereignDesc: "Вся резиденция. Закрытый периметр, spa, infinity-бассейн, шеф, охрана, персональный concierge и протокол прибытия любого уровня.",
		sovereign1: "Вся усадьба под вас",
		sovereign2: "Шеф, spa, бассейн",
		sovereign3: "Охрана и медпротокол",
		sovereign4: "Прибытие любого формата",
		select: "ВЫБРАТЬ →",
		request: "ЗАПРОСИТЬ →",
		featured: "ЧАЩЕ ВЫБИРАЮТ",
		epic: "ПОЛНЫЙ КОНТРОЛЬ",
		cinema: "РЕЗИДЕНЦИЯ",
		cinemaTitle: "Резиденция. Лес. Никого рядом.",
		cinemaLead: "Не дача и не отель. Геометрия бетона, чёрная вода, лес. Место, в котором вас нет в сети.",
		phone: "ПРОТОКОЛ ТЕЛЕФОНА",
		phoneTitle: "Телефон остаётся. Вы — недоступны.",
		phoneLead: "Устройство передаётся concierge и хранится до конца пребывания. Обычные сообщения ждут возвращения.",
		t1: "Передача",
		t1t: "Вы отдаёте устройство concierge в начале пребывания.",
		t2: "Тишина",
		t2t: "Уведомления не входят в резиденцию.",
		t3: "Важное",
		t3t: "Только действительно важное проходит через concierge.",
		concierge: "CONCIERGE",
		conciergeTitle: "Пока вы недоступны — кто-то остаётся доступен вместо вас.",
		conciergeText: "Выбираете concierge: женщина или мужчина. Один человек рядом. Телефон у него. Охрана на периметре.",
		conciergePick: "СВАЙП · ВЫБОР",
		all: "ВСЕ",
		female: "ЖЕНЩИНЫ",
		male: "МУЖЧИНЫ",
		important: "ТОЛЬКО ВАЖНОЕ",
		importantText: "Мы не тревожим по мелочам. Если происходит действительно важное — вам передадут.",
		built: "ОРГАНИЗОВАНО ПОД ВАС",
		servicesTitle: "Вам не нужно думать о деталях.",
		servicesLead: "От прибытия до возвращения основные детали согласуются заранее.",
		loc: "ВИЛЛА",
		locT: "Приватная резиденция в Московской области. Бетон, стекло, лес.",
		spa: "SPA",
		spaT: "Каменный wet room, пар, тишина. Без расписания и чужих гостей.",
		pool: "БАССЕЙН",
		poolT: "Чёрная вода на террасе. Ночью — только отражение дома.",
		priv: "ПРИВАТНОСТЬ",
		privT: "Минимум внешнего шума. Максимум контроля над своим временем.",
		arrival: "ПРОТОКОЛ ПРИБЫТИЯ",
		arrivalTitle: "Вы можете приехать сами. Или мы заберём вас.",
		arrivalText: "После подтверждения согласуем точку встречи и маршрут. Точный адрес не публикуется.",
		arrivalPin: "EXACT LOCATION · AFTER CONFIRMATION",
		final: "ФИНАЛЬНЫЙ ШАГ",
		ready: "ГОТОВЫ",
		disappear: "ОТКЛЮЧИТЬСЯ?",
		finalText: "Никаких форм. Напишите в Telegram. Формат, даты и детали — только там.",
		tg: "НАПИСАТЬ В TELEGRAM →",
		direct: "TELEGRAM · INSTAGRAM",
		wait: "THE WORLD CAN WAIT.",
		protocol: "КАК ЭТО РАБОТАЕТ",
		protocolTitle: "Пять кадров. Один сценарий.",
		protocolLead: "От запроса до тишины — без форм и лишних людей.",
		p1: "ЗАПРОС",
		p1t: "Пишете в Telegram. Согласуем формат и даты.",
		p2: "ПРИБЫТИЕ",
		p2t: "Сами или трансфер. Адрес — после подтверждения.",
		p3: "ТЕЛЕФОН",
		p3t: "Устройство уходит concierge. Вы остаётесь без сигнала.",
		p4: "ПРЕБЫВАНИЕ",
		p4t: "Вилла, spa, вода, лес. Связь только если важно.",
		p5: "ОХРАНА",
		p5t: "Периметр закрыт. Concierge на связи вместо вас.",
		swipe: "СВАЙП · РЕЗИДЕНЦИИ",
		guard: "ПЕРИМЕТР",
		faq: "FAQ",
		faqTitle: "Коротко, без формы.",
		faqLead: "Остальное — в Telegram.",
		q1: "Как забронировать?",
		a1: "Напишите в Telegram. Форм нет. Формат, даты и детали согласуем там.",
		q2: "Что с телефоном?",
		a2: "Передаёте concierge на время пребывания. Обычные сообщения ждут. Важное — через нас.",
		q3: "Где это?",
		a3: "Московская область. Точный адрес — только после подтверждения.",
		q4: "Можно с кем-то?",
		a4: "Да, если согласуем заранее. Чужих гостей на локации нет.",
		q5: "Как с едой?",
		a5: "OFFLINE — простая кухня. DARKNESS — расширенное меню. PRIVATE — под вас. SOVEREIGN — шеф.",
		q6: "Съёмка и отмена?",
		a6: "Гостей не фотографируем, лица и адрес не публикуем. Условия отмены — в Telegram до подтверждения.",
		trust: "ПРОТОКОЛ",
		trust1: "БЕЗ СЪЁМКИ ГОСТЕЙ",
		trust1t: "Ни фото, ни сторис с вашей стороны. Мы тоже не снимаем.",
		trust2: "АДРЕС ПОСЛЕ ПОДТВЕРЖДЕНИЯ",
		trust2t: "Публичной геолокации нет. Точка — только когда всё согласовано.",
		trust3: "ТОЛЬКО ПРЯМАЯ СВЯЗЬ",
		trust3t: "Telegram и Instagram. Без форм, без колл-центра.",
		ig: "INSTAGRAM",
		boot: "// PROTOCOL",
		bootWait: "ОТКЛЮЧЕНИЕ",
		boot1: "СВЯЗЬ",
		boot2: "ЛОКАЦИЯ",
		boot3: "ТИШИНА"
	},
	en: {
		kicker: "PRIVATE SERVICE · MOSCOW REGION",
		hero1: "BE",
		hero2: "UNAVAILABLE.",
		typewriter: "You don't have to disappear. You simply stop being available.",
		from: "FROM",
		scroll: "SCROLL TO DISCONNECT",
		concept: "THE CONCEPT",
		quote1: "You don't have to disappear.",
		quote2: "You simply stop being available.",
		intro1: "PRIVATE STATE is an organized stay in digital silence. A private residence outside Moscow: concrete, glass, forest.",
		intro2: "Choose the format. We prepare the estate, spa, pool, arrival and concierge. The address is shared only after confirmation.",
		stills: "THE ESTATE",
		still1: "VILLA",
		still2: "SUITE",
		still3: "SPA",
		choose: "CHOOSE YOUR STATE",
		three: "Four ways to become unavailable.",
		note: "MOSCOW REGION · PRIVATE ESTATES · ₽ RUB",
		offlineDesc: "Full digital disconnect. A prepared villa, phone held by the concierge, silence without a network.",
		offline1: "Private villa ready",
		offline2: "Phone with concierge",
		offline3: "Concierge on the line",
		offline4: "Kitchen · no transfer",
		darknessDesc: "Deeper. Individually prepared residence, spa, pool and extended support.",
		darkness1: "Spa and pool",
		darkness2: "Transfer on request",
		darkness3: "Extended menu",
		darkness4: "Concierge and arrival",
		privateDesc: "A fully individual scenario. Location, route, support and details built around you.",
		private1: "Your villa and scenario",
		private2: "Transfer",
		private3: "Personal concierge",
		private4: "Kitchen and details to brief",
		sovereignDesc: "The entire estate. Closed perimeter, spa, infinity pool, chef, security, personal concierge and arrival at any level.",
		sovereign1: "Whole estate",
		sovereign2: "Chef, spa, pool",
		sovereign3: "Security and medical protocol",
		sovereign4: "Any arrival format",
		select: "SELECT →",
		request: "REQUEST →",
		featured: "MOST CHOSEN",
		epic: "FULL CONTROL",
		cinema: "THE ESTATE",
		cinemaTitle: "Residence. Forest. No one nearby.",
		cinemaLead: "Not a dacha. Not a hotel. Concrete geometry, black water, forest. A place where you are not online.",
		phone: "THE PHONE PROTOCOL",
		phoneTitle: "The phone stays. You become unavailable.",
		phoneLead: "The device is handed to the concierge and stored until the stay ends. Ordinary messages can wait.",
		t1: "Handover",
		t1t: "You give the device to the concierge at the start.",
		t2: "Silence",
		t2t: "Notifications do not enter the residence.",
		t3: "Essential",
		t3t: "Only what truly matters is passed through.",
		concierge: "CONCIERGE",
		conciergeTitle: "While you are unavailable, someone remains available for you.",
		conciergeText: "Choose your concierge: woman or man. One person beside you. The phone with them. Security on the perimeter.",
		conciergePick: "SWIPE · CHOOSE",
		all: "ALL",
		female: "WOMEN",
		male: "MEN",
		important: "ESSENTIAL ONLY",
		importantText: "We do not interrupt for small things. If something truly matters, it reaches you.",
		built: "ARRANGED FOR YOU",
		servicesTitle: "You do not have to think about the details.",
		servicesLead: "From arrival to return, the main details are agreed in advance.",
		loc: "VILLA",
		locT: "A private residence in the Moscow region. Concrete, glass, forest.",
		spa: "SPA",
		spaT: "Stone wet room, steam, silence. No schedule and no other guests.",
		pool: "POOL",
		poolT: "Black water on the terrace. At night — only the house reflected.",
		priv: "PRIVACY",
		privT: "Less outside noise. More control of your time.",
		arrival: "ARRIVAL PROTOCOL",
		arrivalTitle: "You may arrive yourself. Or we collect you.",
		arrivalText: "After confirmation we agree the meeting point and route. The exact address is never published.",
		arrivalPin: "EXACT LOCATION · AFTER CONFIRMATION",
		final: "FINAL STEP",
		ready: "READY TO",
		disappear: "DISCONNECT?",
		finalText: "No forms. Write in Telegram. Format, dates and details only there.",
		tg: "WRITE IN TELEGRAM →",
		direct: "TELEGRAM · INSTAGRAM",
		wait: "THE WORLD CAN WAIT.",
		protocol: "HOW IT WORKS",
		protocolTitle: "Five frames. One scenario.",
		protocolLead: "From request to silence — no forms, no extra people.",
		p1: "REQUEST",
		p1t: "Write in Telegram. We agree format and dates.",
		p2: "ARRIVAL",
		p2t: "Yourself or transfer. Address after confirmation.",
		p3: "PHONE",
		p3t: "The device goes to the concierge. You stay without signal.",
		p4: "STAY",
		p4t: "Villa, spa, water, forest. Contact only if it matters.",
		p5: "SECURITY",
		p5t: "Perimeter closed. The concierge stays on the line for you.",
		swipe: "SWIPE · RESIDENCES",
		guard: "PERIMETER",
		faq: "FAQ",
		faqTitle: "Short answers. No form.",
		faqLead: "The rest is in Telegram.",
		q1: "How do I book?",
		a1: "Write in Telegram. No forms. Format, dates and details are agreed there.",
		q2: "What about the phone?",
		a2: "You hand it to the concierge for the stay. Ordinary messages wait. What matters comes through us.",
		q3: "Where is it?",
		a3: "Moscow region. The exact address only after confirmation.",
		q4: "Can I bring someone?",
		a4: "Yes, if we agree in advance. There are no other guests on site.",
		q5: "What about food?",
		a5: "OFFLINE — simple kitchen. DARKNESS — extended menu. PRIVATE — to brief. SOVEREIGN — chef.",
		q6: "Photos and cancellation?",
		a6: "We do not photograph guests, faces or the address. Cancellation terms are in Telegram before confirmation.",
		trust: "PROTOCOL",
		trust1: "NO GUEST PHOTOGRAPHY",
		trust1t: "No photos, no stories of you. We do not shoot either.",
		trust2: "ADDRESS AFTER CONFIRMATION",
		trust2t: "No public geolocation. The point only when everything is agreed.",
		trust3: "DIRECT CONTACT ONLY",
		trust3t: "Telegram and Instagram. No forms, no call centre.",
		ig: "INSTAGRAM",
		boot: "// PROTOCOL",
		bootWait: "DISCONNECTING",
		boot1: "LINK",
		boot2: "LOCATION",
		boot3: "SILENCE"
	},
	zh: {
		kicker: "私人服务 · 莫斯科地区",
		hero1: "暂时",
		hero2: "不可用。",
		typewriter: "你不需要消失，只需要暂时不再回应这个世界。",
		from: "起",
		scroll: "向下，进入离线状态",
		concept: "概念",
		quote1: "你不需要消失。",
		quote2: "只需要暂时不再回应。",
		intro1: "PRIVATE STATE 是位于莫斯科郊外的私人数字静默体验。私人居所：混凝土、玻璃、森林。",
		intro2: "选择形式。我们安排地点、水疗、泳池、抵达与私人管家。地址仅在确认后提供。",
		stills: "居所",
		still1: "VILLA",
		still2: "SUITE",
		still3: "SPA",
		choose: "选择状态",
		three: "四种方式，暂时离开世界。",
		note: "MOSCOW REGION · PRIVATE ESTATES · ₽ RUB",
		offlineDesc: "完全数字断开。准备好的别墅，手机由管家保管，没有网络的安静。",
		offline1: "别墅就绪",
		offline2: "手机由管家保管",
		offline3: "管家在线",
		offline4: "厨房 · 不含接送",
		darknessDesc: "更深层。个性化居所、水疗、泳池与更完整的支持。",
		darkness1: "水疗与泳池",
		darkness2: "按需接送",
		darkness3: "扩展餐食",
		darkness4: "管家与抵达",
		privateDesc: "完全私人定制。地点、路线、支持均按你安排。",
		private1: "专属别墅与方案",
		private2: "接送",
		private3: "私人管家",
		private4: "餐食与细节按你安排",
		sovereignDesc: "整座庄园。封闭边界、水疗、无边泳池、主厨、安保、全天候管家，以及任意级别的抵达。",
		sovereign1: "整座庄园",
		sovereign2: "主厨、水疗、泳池",
		sovereign3: "安保与医疗协议",
		sovereign4: "任意抵达方式",
		select: "选择 →",
		request: "申请 →",
		featured: "最常选择",
		epic: "完全掌控",
		cinema: "居所",
		cinemaTitle: "居所。森林。附近没有人。",
		cinemaLead: "不是乡间木屋，也不是酒店。混凝土、黑水、森林。一个你不在线的地方。",
		phone: "手机协议",
		phoneTitle: "手机留下。你暂时不可用。",
		phoneLead: "设备交给管家保管，直到体验结束。普通消息可以等待。",
		t1: "交接",
		t1t: "进入后将设备交给管家。",
		t2: "安静",
		t2t: "通知不会进入居所。",
		t3: "重要信息",
		t3t: "真正重要的信息会通过管家传达。",
		concierge: "私人管家",
		conciergeTitle: "当你暂时不可用时，有人替你保持联系。",
		conciergeText: "选择管家：女性或男性。身边一个人。手机关在那里。外围有安保。",
		conciergePick: "滑动 · 选择",
		all: "全部",
		female: "女性",
		male: "男性",
		important: "仅重要信息",
		importantText: "我们不会因为小事打扰你。如果发生真正重要的事情，你会知道。",
		built: "为你安排",
		servicesTitle: "你不需要考虑这些细节。",
		servicesLead: "从抵达到离开，重要细节都会提前确认。",
		loc: "别墅",
		locT: "莫斯科地区的私人居所。混凝土、玻璃、森林。",
		spa: "水疗",
		spaT: "石材湿区、蒸汽、安静。没有时间表，也没有其他客人。",
		pool: "泳池",
		poolT: "露台上的黑水。夜里只有房子的倒影。",
		priv: "隐私",
		privT: "减少外界干扰，重新掌控自己的时间。",
		arrival: "抵达协议",
		arrivalTitle: "你可以自己抵达。也可以由我们安排。",
		arrivalText: "确认后，我们会协调会面地点与路线。具体地址不会公开发布。",
		arrivalPin: "EXACT LOCATION · AFTER CONFIRMATION",
		final: "最后一步",
		ready: "准备好",
		disappear: "断开？",
		finalText: "无需表格。在 Telegram 联系。形式、日期与细节只在那里确认。",
		tg: "通过 TELEGRAM 联系 →",
		direct: "TELEGRAM · INSTAGRAM",
		wait: "THE WORLD CAN WAIT.",
		protocol: "如何进行",
		protocolTitle: "五个画面。一个场景。",
		protocolLead: "从询价到安静，没有表格，没有多余的人。",
		p1: "询价",
		p1t: "在 Telegram 联系。确认形式与日期。",
		p2: "抵达",
		p2t: "自行抵达或接送。地址仅在确认后提供。",
		p3: "手机",
		p3t: "设备交给管家。你进入离线。",
		p4: "停留",
		p4t: "别墅、水疗、水面、森林。仅在必要时联系。",
		p5: "安保",
		p5t: "边界关闭。管家替你保持联系。",
		swipe: "滑动 · 居所",
		guard: "外围",
		faq: "常见问题",
		faqTitle: "简短回答。没有表格。",
		faqLead: "其余在 Telegram。",
		q1: "如何预订？",
		a1: "在 Telegram 联系。没有表格。形式、日期与细节在那里确认。",
		q2: "手机怎么办？",
		a2: "入住期间交给管家。普通消息可以等待。重要信息由我们转达。",
		q3: "在哪里？",
		a3: "莫斯科地区。具体地址仅在确认后提供。",
		q4: "可以带人吗？",
		a4: "可以，需提前确认。现场没有其他客人。",
		q5: "餐饮呢？",
		a5: "OFFLINE — 简单厨房。DARKNESS — 扩展餐食。PRIVATE — 按你安排。SOVEREIGN — 主厨。",
		q6: "拍摄与取消？",
		a6: "我们不为客人拍照。不公开面孔与地址。取消条件在确认前于 Telegram 约定。",
		trust: "协议",
		trust1: "不为客人拍摄",
		trust1t: "没有照片，也没有你的动态。我们也不拍。",
		trust2: "确认后才给地址",
		trust2t: "没有公开定位。一切确认后再告知地点。",
		trust3: "仅直接联系",
		trust3t: "Telegram 与 Instagram。没有表格，没有呼叫中心。",
		ig: "INSTAGRAM",
		boot: "// PROTOCOL",
		bootWait: "断开中",
		boot1: "连接",
		boot2: "地点",
		boot3: "静默"
	}
};
var PKG_KEYS = {
	offline: {
		desc: "offlineDesc",
		items: [
			"offline1",
			"offline2",
			"offline3",
			"offline4"
		]
	},
	darkness: {
		desc: "darknessDesc",
		items: [
			"darkness1",
			"darkness2",
			"darkness3",
			"darkness4"
		]
	},
	private: {
		desc: "privateDesc",
		items: [
			"private1",
			"private2",
			"private3",
			"private4"
		]
	},
	sovereign: {
		desc: "sovereignDesc",
		items: [
			"sovereign1",
			"sovereign2",
			"sovereign3",
			"sovereign4"
		]
	}
};
var GALLERY = [
	{
		src: media("/images/hero.jpg"),
		cap: "01 · FOREST"
	},
	{
		src: media("/images/house.jpg"),
		cap: "02 · VILLA"
	},
	{
		src: media("/images/house-2.jpg"),
		cap: "03 · NIGHT"
	},
	{
		src: media("/images/house-3.jpg"),
		cap: "04 · GLASS"
	},
	{
		src: media("/images/house-private.jpg"),
		cap: "05 · PRIVATE"
	},
	{
		src: media("/images/house-4.jpg"),
		cap: "06 · WATER"
	},
	{
		src: media("/images/pool.jpg"),
		cap: "07 · POOL"
	},
	{
		src: media("/images/spa.jpg"),
		cap: "08 · SPA"
	}
];
var CONCIERGES = [
	{
		src: media("/images/concierge-f.jpg"),
		name: "ANNA",
		gender: "f"
	},
	{
		src: media("/images/concierge.jpg"),
		name: "LEO",
		gender: "m"
	},
	{
		src: media("/images/concierge-f2.jpg"),
		name: "MIRA",
		gender: "f"
	},
	{
		src: media("/images/concierge-m2.jpg"),
		name: "NOAH",
		gender: "m"
	},
	{
		src: media("/images/concierge-f3.jpg"),
		name: "EVA",
		gender: "f"
	},
	{
		src: media("/images/concierge-m3.jpg"),
		name: "KAI",
		gender: "m"
	}
];
var BOOT_MS = 3400;
function Landing() {
	const [lang, setLang] = (0, import_react.useState)("ru");
	const [boot, setBoot] = (0, import_react.useState)(true);
	const [typed, setTyped] = (0, import_react.useState)("");
	const [offline, setOffline] = (0, import_react.useState)(false);
	const t = translations[lang];
	(0, import_react.useEffect)(() => {
		try {
			if (sessionStorage.getItem("ps-boot-v4") === "1") {
				setBoot(false);
				return;
			}
		} catch {}
		const id = window.setTimeout(() => {
			try {
				sessionStorage.setItem("ps-boot-v4", "1");
			} catch {}
			setBoot(false);
		}, BOOT_MS);
		return () => window.clearTimeout(id);
	}, []);
	(0, import_react.useEffect)(() => {
		if (boot) return;
		const full = t.typewriter;
		setTyped("");
		let i = 0;
		const id = window.setInterval(() => {
			i += 1;
			setTyped(full.slice(0, i));
			if (i >= full.length) window.clearInterval(id);
		}, 28);
		return () => window.clearInterval(id);
	}, [boot, t.typewriter]);
	const generalTg = TELEGRAM_URL;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-svh bg-bg text-fg",
		children: [
			boot && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BootScreen, { t }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
				className: "pointer-events-none fixed -z-10 size-px opacity-0",
				src: media("/video/estate.mp4"),
				muted: true,
				playsInline: true,
				preload: "auto",
				"aria-hidden": true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "fixed inset-x-0 top-0 z-40 flex items-center justify-between bg-bg/80 px-5 py-4 backdrop-blur-md md:px-16",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
					href: "#top",
					className: "flex items-center gap-3 no-underline",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "font-mono text-xs tracking-[0.28em]",
						children: [
							"P",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "mx-1 inline-block size-1.5 rounded-full bg-green" }),
							"S"
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "hidden font-mono text-xs tracking-widest text-dim sm:inline",
						children: "PRIVATE STATE"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [
						[
							"ru",
							"en",
							"zh"
						].map((code) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setLang(code),
							className: clsx("font-mono text-xs tracking-widest", lang === code ? "text-green" : "text-dim hover:text-fg"),
							children: code.toUpperCase()
						}, code)),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: TELEGRAM_URL,
							target: "_blank",
							rel: "noreferrer",
							className: "flex size-9 items-center justify-center rounded-full border border-border text-green no-underline hover:border-green",
							"aria-label": "Telegram",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TgIcon, {})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: INSTAGRAM_URL,
							target: "_blank",
							rel: "noreferrer",
							className: "flex size-9 items-center justify-center rounded-full border border-border text-green no-underline hover:border-green",
							"aria-label": "Instagram",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Instagram, {
								className: "size-3.5",
								strokeWidth: 1.7
							})
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				id: "top",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "relative flex min-h-svh items-center overflow-hidden px-5 pb-24 pt-28 md:px-16",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeroMedia, {
								src: media("/video/estate.mp4"),
								poster: media("/images/hero.jpg")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-b from-bg/40 via-bg/55 to-bg" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative z-10 w-full max-w-6xl",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "mb-6 flex items-center gap-3 font-mono text-xs tracking-widest text-muted",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-1.5 rounded-full bg-green" }), t.kicker]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
										className: "text-6xl font-medium leading-none tracking-tighter md:text-8xl lg:text-9xl",
										children: [t.hero1, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "mt-1 block text-green",
											children: t.hero2
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "mt-8 max-w-xl font-mono text-sm leading-relaxed text-muted md:text-base",
										children: [typed, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "ml-1 inline-block h-4 w-1.5 translate-y-0.5 bg-green" })]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "absolute inset-x-5 bottom-8 z-10 flex items-end justify-between md:inset-x-16",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "hidden font-mono text-xs text-dim sm:block",
									children: "MOSCOW REGION"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-mono text-xs tracking-widest text-dim",
									children: t.scroll
								})]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
						className: "px-5 py-24 md:px-16",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mx-auto grid max-w-6xl gap-10 md:grid-cols-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mb-4 font-mono text-xs tracking-widest text-green",
								children: ["// ", t.concept]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
								className: "text-4xl font-medium tracking-tight md:text-6xl",
								children: [t.quote1, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mt-2 block text-muted",
									children: t.quote2
								})]
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-col justify-end",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm leading-relaxed text-muted md:text-base",
									children: t.intro1
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-4 text-sm leading-relaxed text-muted md:text-base",
									children: t.intro2
								})]
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
						className: "px-5 pb-24 md:px-16",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mx-auto max-w-6xl",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mb-6 font-mono text-xs tracking-widest text-green",
								children: ["// ", t.swipe]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SwipeGallery, { items: GALLERY })]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
						className: "px-5 py-10 md:px-16",
						id: "formats",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mx-auto max-w-6xl",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mb-3 font-mono text-xs tracking-widest text-green",
									children: ["// ", t.choose]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "text-4xl font-medium tracking-tight md:text-6xl",
									children: t.three
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-4 font-mono text-xs text-dim",
									children: t.note
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-12 grid gap-3 md:grid-cols-2",
									children: PACKAGES.map((pkg) => {
										const keys = PKG_KEYS[pkg.id];
										const epic = Boolean(pkg.epic);
										return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
											className: clsx("relative overflow-hidden border border-border", epic && "md:col-span-2"),
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
												src: pkg.bg,
												alt: "",
												className: "absolute inset-0 size-full object-cover opacity-40",
												loading: "lazy",
												decoding: "async"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "relative bg-bg/70 p-6 md:p-8",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "flex items-center justify-between gap-3",
														children: [
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
																className: "font-mono text-xs tracking-widest text-green",
																children: pkg.code
															}),
															pkg.featured && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "font-mono text-xs text-green",
																children: t.featured
															}),
															epic && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "font-mono text-xs text-green",
																children: t.epic
															})
														]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
														className: "mt-4 text-3xl font-medium tracking-tight md:text-5xl",
														children: pkg.name
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
														className: "mt-2 font-mono text-sm text-green",
														children: [
															t.from,
															" ",
															pkg.price
														]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
														className: "mt-5 max-w-2xl text-sm leading-relaxed text-muted",
														children: t[keys.desc]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
														className: "mt-6 max-w-xl",
														children: keys.items.map((key) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
															className: "border-b border-border py-2.5 text-sm text-muted",
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "mr-2 text-green",
																children: "↗"
															}), t[key]]
														}, key))
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
														href: TELEGRAM_URL,
														target: "_blank",
														rel: "noreferrer",
														className: "mt-7 inline-block font-mono text-xs tracking-widest text-fg no-underline hover:text-green",
														children: epic ? t.request : t.select
													})
												]
											})]
										}, pkg.id);
									})
								})
							]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "relative min-h-svh overflow-hidden",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LazyVideo, {
								src: media("/video/spa.mp4"),
								poster: media("/images/pool.jpg"),
								className: "absolute inset-0",
								fit: true
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-t from-bg via-bg/50 to-bg/30" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "relative z-10 flex min-h-svh items-end px-5 py-20 md:px-16",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "max-w-3xl",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "mb-4 font-mono text-xs tracking-widest text-green",
											children: ["// ", t.cinema]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
											className: "text-4xl font-medium tracking-tight md:text-6xl",
											children: t.cinemaTitle
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-5 max-w-xl text-sm leading-relaxed text-muted md:text-base",
											children: t.cinemaLead
										})
									]
								})
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
						className: "px-5 py-24 md:px-16",
						id: "protocol",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mx-auto max-w-6xl",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mb-3 font-mono text-xs tracking-widest text-green",
									children: ["// ", t.protocol]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "text-4xl font-medium tracking-tight md:text-6xl",
									children: t.protocolTitle
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-4 max-w-xl text-sm text-muted",
									children: t.protocolLead
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProtocolFilm, { t })
							]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
						className: "px-5 py-24 md:px-16",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mx-auto grid max-w-6xl items-center gap-12 md:grid-cols-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhoneStage, {
								offline,
								onToggle: () => setOffline((v) => !v)
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mb-4 font-mono text-xs tracking-widest text-green",
									children: ["// ", t.phone]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "text-4xl font-medium tracking-tight md:text-5xl",
									children: t.phoneTitle
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-5 text-sm leading-relaxed text-muted",
									children: t.phoneLead
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-8 border-t border-border",
									children: [
										[
											"01",
											t.t1,
											t.t1t
										],
										[
											"02",
											t.t2,
											t.t2t
										],
										[
											"03",
											t.t3,
											t.t3t
										]
									].map(([n, title, body]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid grid-cols-[3rem_1fr] border-b border-border py-5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-mono text-xs text-green",
											children: n
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-sm",
											children: title
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-1 text-xs leading-relaxed text-dim",
											children: body
										})] })]
									}, n))
								})
							] })]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
						className: "px-5 py-24 md:px-16",
						id: "concierge",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mx-auto max-w-6xl",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mb-3 font-mono text-xs tracking-widest text-green",
									children: ["// ", t.concierge]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "max-w-3xl text-4xl font-medium tracking-tight md:text-5xl",
									children: t.conciergeTitle
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-5 max-w-xl text-sm leading-relaxed text-muted",
									children: t.conciergeText
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConciergeSwipe, { t }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-4 grid gap-4 md:grid-cols-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "overflow-hidden border border-border",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
											src: media("/images/security.jpg"),
											alt: "",
											className: "h-48 w-full object-cover",
											loading: "lazy",
											decoding: "async"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "px-3 py-2 font-mono text-xs tracking-widest text-green",
											children: t.guard
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "border border-border bg-bg-soft p-5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mb-3 font-mono text-xs tracking-widest text-green",
											children: t.important
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-sm leading-relaxed text-muted",
											children: t.importantText
										})]
									})]
								})
							]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
						className: "px-5 py-20 md:px-16",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mx-auto max-w-6xl",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mb-3 font-mono text-xs tracking-widest text-green",
									children: ["// ", t.built]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "text-4xl font-medium tracking-tight md:text-6xl",
									children: t.servicesTitle
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-4 max-w-xl text-sm leading-relaxed text-muted",
									children: t.servicesLead
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-12 grid gap-2 sm:grid-cols-2 lg:grid-cols-4",
									children: [
										{
											img: media("/images/house-3.jpg"),
											title: t.loc,
											text: t.locT
										},
										{
											img: media("/images/spa.jpg"),
											title: t.spa,
											text: t.spaT
										},
										{
											img: media("/images/pool.jpg"),
											title: t.pool,
											text: t.poolT
										},
										{
											img: media("/images/room.jpg"),
											title: t.priv,
											text: t.privT
										}
									].map((card) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
										className: "border border-border bg-surface",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
											src: card.img,
											alt: "",
											className: "h-40 w-full object-cover",
											loading: "lazy",
											decoding: "async"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "p-5",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "mb-2 font-mono text-xs tracking-widest text-green",
												children: card.title
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs leading-relaxed text-muted",
												children: card.text
											})]
										})]
									}, card.title))
								})
							]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "relative min-h-svh overflow-hidden",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LazyVideo, {
								src: media("/video/moscow.mp4"),
								poster: media("/images/house-5.jpg"),
								className: "absolute inset-0",
								fit: true
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-t from-bg via-bg/70 to-bg/40" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative z-10 mx-auto flex min-h-svh max-w-6xl flex-col justify-end px-5 py-20 md:px-16",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "mb-4 font-mono text-xs tracking-widest text-green",
										children: ["// ", t.arrival]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "max-w-3xl text-4xl font-medium tracking-tight md:text-6xl",
										children: t.arrivalTitle
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-5 max-w-xl text-sm leading-relaxed text-muted md:text-base",
										children: t.arrivalText
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "mt-8 font-mono text-xs tracking-widest text-green",
										children: ["MOSCOW REGION", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "mt-2 block text-dim",
											children: t.arrivalPin
										})]
									})
								]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
						className: "px-5 py-20 md:px-16",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mx-auto max-w-6xl",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mb-8 font-mono text-xs tracking-widest text-green",
								children: ["// ", t.trust]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid gap-3 md:grid-cols-3",
								children: [
									[t.trust1, t.trust1t],
									[t.trust2, t.trust2t],
									[t.trust3, t.trust3t]
								].map(([title, body]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
									className: "border border-border bg-surface p-6",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-mono text-xs tracking-widest text-green",
										children: title
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-3 text-sm leading-relaxed text-muted",
										children: body
									})]
								}, title))
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
						className: "px-5 py-20 md:px-16",
						id: "faq",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mx-auto max-w-6xl",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mb-3 font-mono text-xs tracking-widest text-green",
									children: ["// ", t.faq]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "text-4xl font-medium tracking-tight md:text-6xl",
									children: t.faqTitle
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-4 max-w-xl text-sm text-muted",
									children: t.faqLead
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-10 border-t border-border",
									children: [
										"1",
										"2",
										"3",
										"4",
										"5",
										"6"
									].map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
										className: "group border-b border-border",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("summary", {
											className: "flex min-h-14 cursor-pointer list-none items-center justify-between gap-4 py-4 text-left text-sm",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t[`q${n}`] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-mono text-green group-open:rotate-45",
												children: "+"
											})]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "pb-5 text-sm leading-relaxed text-muted",
											children: t[`a${n}`]
										})]
									}, n))
								})
							]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						id: "request",
						className: "relative flex min-h-svh flex-col items-center justify-center overflow-hidden px-5 py-24 text-center",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: media("/images/estate.jpg"),
								alt: "",
								className: "absolute inset-0 size-full object-cover",
								loading: "lazy",
								decoding: "async"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-bg/80" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative z-10 flex flex-col items-center",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "mb-6 font-mono text-xs tracking-widest text-green",
										children: ["// ", t.final]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
										className: "text-6xl font-medium leading-none tracking-tighter md:text-8xl lg:text-9xl",
										children: [t.ready, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "mt-2 block text-green",
											children: t.disappear
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-8 max-w-lg text-sm leading-relaxed text-muted",
										children: t.finalText
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
										href: generalTg,
										target: "_blank",
										rel: "noreferrer",
										className: "mt-10 inline-flex min-h-12 w-full max-w-sm items-center justify-center gap-3 bg-green px-6 font-mono text-xs tracking-widest text-bg no-underline hover:bg-transparent hover:text-green hover:ring-1 hover:ring-green",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TgIcon, {}), t.tg]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-4 font-mono text-xs text-dim",
										children: t.direct
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-2 flex items-center gap-4 font-mono text-xs",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
											href: TELEGRAM_URL,
											target: "_blank",
											rel: "noreferrer",
											className: "text-dim no-underline hover:text-green",
											children: "Telegram"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
											href: INSTAGRAM_URL,
											target: "_blank",
											rel: "noreferrer",
											className: "text-dim no-underline hover:text-green",
											children: "Instagram"
										})]
									})
								]
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
				className: "flex items-center justify-between px-5 py-8 font-mono text-xs text-dim md:px-16",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "PRIVATE STATE" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t.wait }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: INSTAGRAM_URL,
						target: "_blank",
						rel: "noreferrer",
						className: "text-dim no-underline hover:text-green",
						children: INSTAGRAM
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				href: generalTg,
				target: "_blank",
				rel: "noreferrer",
				className: "fixed bottom-4 left-4 right-4 z-50 flex min-h-12 items-center justify-center bg-green font-mono text-xs tracking-widest text-bg no-underline md:hidden",
				children: t.tg
			})
		]
	});
}
function BootScreen({ t }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "ps-boot fixed inset-0 z-[100] flex flex-col items-center justify-center bg-bg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "pointer-events-none absolute inset-0 overflow-hidden",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-x-0 h-px bg-green/50 [animation:ps-scan_2.4s_linear_infinite]" })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "ps-boot-inner relative z-10 flex w-full max-w-sm flex-col items-center px-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-mono text-xs tracking-[0.4em] text-green",
					children: t.boot
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-8 text-4xl font-medium tracking-tighter",
					children: ["PRIVATE ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-green",
						children: "STATE"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-6 font-mono text-xs tracking-widest text-dim",
					children: t.bootWait
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
					className: "mt-10 w-full space-y-3 font-mono text-xs tracking-widest text-muted",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: ["01 ", t.boot1] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: ["02 ", t.boot2] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: ["03 ", t.boot3] })
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-10 h-px w-full bg-border",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-px bg-green [animation:ps-bar_2.8s_linear_forwards]" })
				})
			]
		})]
	});
}
function HeroMedia({ src, poster }) {
	const ref = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		const v = ref.current;
		if (!v) return;
		v.muted = true;
		v.play().catch(() => void 0);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
		ref,
		className: "absolute inset-0 size-full object-cover",
		src,
		poster,
		muted: true,
		loop: true,
		playsInline: true,
		autoPlay: true,
		preload: "auto"
	});
}
function LazyVideo({ src, poster, className, fit }) {
	const [on, setOn] = (0, import_react.useState)(false);
	const box = (0, import_react.useRef)(null);
	const vid = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		const el = box.current;
		if (!el) return;
		const io = new IntersectionObserver(([entry]) => {
			if (entry.isIntersecting) setOn(true);
		}, {
			rootMargin: "200px",
			threshold: .01
		});
		io.observe(el);
		return () => io.disconnect();
	}, []);
	(0, import_react.useEffect)(() => {
		const v = vid.current;
		if (!v || !on) return;
		v.play().catch(() => void 0);
	}, [on]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		ref: box,
		className: className ?? "relative overflow-hidden",
		children: on ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
			ref: vid,
			className: clsx("size-full object-cover", fit && "absolute inset-0"),
			src,
			poster,
			muted: true,
			loop: true,
			playsInline: true,
			preload: "metadata"
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src: poster,
			alt: "",
			className: clsx("size-full object-cover", fit && "absolute inset-0")
		})
	});
}
function SwipeGallery({ items }) {
	const [i, setI] = (0, import_react.useState)(0);
	const start = (0, import_react.useRef)(null);
	const hover = (0, import_react.useRef)(false);
	const go = (dir) => setI((n) => (n + dir + items.length) % items.length);
	(0, import_react.useEffect)(() => {
		const id = window.setInterval(() => {
			if (!hover.current) go(1);
		}, 4800);
		return () => window.clearInterval(id);
	}, [items.length]);
	const pointerStart = (x) => {
		start.current = x;
	};
	const pointerEnd = (x) => {
		if (start.current == null) return;
		const dx = x - start.current;
		if (dx > 40) go(-1);
		if (dx < -40) go(1);
		start.current = null;
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative select-none overflow-hidden border border-border",
		onMouseEnter: () => {
			hover.current = true;
		},
		onMouseLeave: () => {
			hover.current = false;
		},
		onTouchStart: (e) => pointerStart(e.touches[0].clientX),
		onTouchEnd: (e) => pointerEnd(e.changedTouches[0].clientX),
		onMouseDown: (e) => pointerStart(e.clientX),
		onMouseUp: (e) => pointerEnd(e.clientX),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src: items[i].src,
			alt: "",
			className: "ps-ken aspect-video w-full object-cover",
			decoding: "async"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "absolute inset-x-0 bottom-0 flex items-center justify-between bg-gradient-to-t from-bg to-transparent px-4 py-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-mono text-xs tracking-widest",
					children: items[i].cap
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex gap-2",
					children: items.map((item, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-label": item.cap,
						onClick: () => setI(idx),
						className: clsx("h-1.5 w-4", idx === i ? "bg-green" : "bg-dim")
					}, item.src))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => go(-1),
						className: "min-h-10 min-w-10 border border-border font-mono text-sm hover:border-green",
						children: "‹"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => go(1),
						className: "min-h-10 min-w-10 border border-border font-mono text-sm hover:border-green",
						children: "›"
					})]
				})
			]
		})]
	});
}
function ConciergeSwipe({ t }) {
	const [filter, setFilter] = (0, import_react.useState)("all");
	const [i, setI] = (0, import_react.useState)(0);
	const start = (0, import_react.useRef)(null);
	const list = (0, import_react.useMemo)(() => filter === "all" ? CONCIERGES : CONCIERGES.filter((c) => c.gender === filter), [filter]);
	(0, import_react.useEffect)(() => {
		setI(0);
	}, [filter]);
	const go = (dir) => setI((n) => (n + dir + list.length) % list.length);
	const person = list[i] ?? list[0];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-10",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mb-4 flex flex-wrap gap-2",
			children: [
				["all", t.all],
				["f", t.female],
				["m", t.male]
			].map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => setFilter(id),
				className: clsx("min-h-10 border px-4 font-mono text-xs tracking-widest", filter === id ? "border-green text-green" : "border-border text-dim hover:text-fg"),
				children: label
			}, id))
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative mx-auto max-w-lg select-none overflow-hidden border border-border md:max-w-2xl",
			onTouchStart: (e) => {
				start.current = e.touches[0].clientX;
			},
			onTouchEnd: (e) => {
				if (start.current == null) return;
				const dx = e.changedTouches[0].clientX - start.current;
				if (dx > 40) go(-1);
				if (dx < -40) go(1);
				start.current = null;
			},
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: person.src,
				alt: "",
				className: "aspect-[3/4] w-full object-cover object-top"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "absolute inset-x-0 bottom-0 flex items-end justify-between bg-gradient-to-t from-bg via-bg/70 to-transparent px-5 py-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-mono text-xs tracking-widest text-green",
						children: t.conciergePick
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-2xl font-medium tracking-tight",
						children: person.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "font-mono text-xs text-dim",
						children: [
							person.gender === "f" ? t.female : t.male,
							" · 0",
							i + 1,
							" / 0",
							list.length
						]
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => go(-1),
						className: "min-h-10 min-w-10 border border-border font-mono text-sm hover:border-green",
						children: "‹"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => go(1),
						className: "min-h-10 min-w-10 border border-border font-mono text-sm hover:border-green",
						children: "›"
					})]
				})]
			})]
		})]
	});
}
function PhoneStage({ offline, onToggle }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative overflow-hidden border border-border bg-surface",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LazyVideo, {
			src: media("/video/phone.mp4"),
			poster: media("/images/phone.jpg"),
			className: "aspect-video w-full"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			onClick: onToggle,
			className: clsx("absolute bottom-4 right-4 flex h-40 w-24 flex-col items-center justify-center rounded-3xl border-2 border-dim bg-bg/90", offline && "ps-phone-offline border-green"),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "ps-bars mb-3 flex h-3 items-end gap-0.5",
					children: [
						1,
						2,
						3,
						4
					].map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "w-1 bg-green",
						style: {
							height: `${n * 3}px`,
							animation: "ps-signal 1.6s ease infinite",
							animationDelay: `${n * 120}ms`
						}
					}, n))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-mono text-xs text-green",
					children: offline ? "OFFLINE" : "NO SIGNAL"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "mt-2 font-mono text-xs text-dim",
					children: "TAP"
				})
			]
		})]
	});
}
function ProtocolFilm({ t }) {
	const steps = [
		{
			poster: media("/images/hero.jpg"),
			k: "p1"
		},
		{
			poster: media("/images/house-5.jpg"),
			k: "p2"
		},
		{
			poster: media("/images/phone.jpg"),
			k: "p3"
		},
		{
			poster: media("/images/spa.jpg"),
			k: "p4"
		},
		{
			poster: media("/images/security.jpg"),
			k: "p5"
		}
	];
	const [i, setI] = (0, import_react.useState)(0);
	(0, import_react.useEffect)(() => {
		const id = window.setInterval(() => setI((n) => (n + 1) % steps.length), 4200);
		return () => window.clearInterval(id);
	}, [steps.length]);
	const step = steps[i];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-10 grid gap-4 md:grid-cols-[1.4fr_0.6fr]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative min-h-72 overflow-hidden border border-border",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: step.poster,
				alt: "",
				className: "size-full min-h-72 object-cover"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "absolute inset-x-0 bottom-0 bg-gradient-to-t from-bg p-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "font-mono text-xs tracking-widest text-green",
					children: [
						"0",
						i + 1,
						" / ",
						t[step.k]
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted",
					children: t[`${step.k}t`]
				})]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
			className: "flex flex-col gap-1",
			children: steps.map((s, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => setI(idx),
				className: clsx("flex w-full min-h-12 items-center justify-between border px-4 text-left font-mono text-xs tracking-widest", idx === i ? "border-green text-green" : "border-border text-dim hover:text-fg"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
					"0",
					idx + 1,
					" ",
					t[s.k]
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "→" })]
			}) }, s.k))
		})]
	});
}
function TgIcon() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		viewBox: "0 0 24 24",
		className: "size-3.5 fill-current",
		"aria-hidden": true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M21.5 3.4 18.2 20c-.2 1-.8 1.2-1.6.8l-4.4-3.3-2.1 2c-.2.3-.5.5-1 .5l.3-4.5 8.2-7.4c.4-.3 0-.5-.5-.2l-10 6.3-4.3-1.3c-.9-.3-.9-.9.2-1.3L20.2 2.6c.8-.3 1.5.2 1.3.8Z" })
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Landing, {});
}
//#endregion
export { Home as component };
